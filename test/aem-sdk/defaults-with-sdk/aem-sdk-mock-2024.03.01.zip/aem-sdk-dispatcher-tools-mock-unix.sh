#!/usr/bin/env bash

mkdir -p dispatcher-sdk-mock/bin
echo "#!/usr/bin/env bash" >> dispatcher-sdk-mock/bin/docker_run.sh
echo "echo \"All your base are belong to us\"" >> dispatcher-sdk-mock/bin/docker_run.sh
chmod +x dispatcher-sdk-mock/bin/docker_run.sh