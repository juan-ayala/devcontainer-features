#!/usr/bin/env bash

mkdir -p dispatcher-sdk-mock/bin
echo "!#/usr/bin/env bash" >> dispatcher-sdk-mock/bin/docker_run.sh
echo "echo \"hello,world\"" >> dispatcher-sdk-mock/bin/docker_run.sh
