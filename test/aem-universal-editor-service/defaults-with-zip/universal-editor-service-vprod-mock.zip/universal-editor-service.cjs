console.log("hello, world");
